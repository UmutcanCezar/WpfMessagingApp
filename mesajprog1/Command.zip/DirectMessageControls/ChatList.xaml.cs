﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using mesajprog1.ViewModel;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mesajprog1.DirectMessageControls
{
    /// <summary>
    /// ChatList.xaml etkileşim mantığı
    /// </summary>
    public partial class ChatList : UserControl
    {
        public ChatList()
        {
            InitializeComponent();
            this.DataContext = new FriendsViewModel();
        }
    }
}

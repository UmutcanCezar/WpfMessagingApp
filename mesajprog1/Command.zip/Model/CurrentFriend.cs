﻿using mesajprog1.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mesajprog1.Model
{
    public class CurrentFriend
    {
        public static FriendDto Currentfriend {  get; set; }
    }
}

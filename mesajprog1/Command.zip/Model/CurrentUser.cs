﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mesajprog1.Model
{
    public class CurrentUser
    {
        public static User Currentuser {  get; set; }
    }
}

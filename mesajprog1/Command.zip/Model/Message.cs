﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mesajprog1.Model
{
    public class Message
    {
        public string SentMessage { get; set; }
        public string ReceivedMessage { get; set; }
        public bool IsMessageReceived { get; set; }
        public string MsgSentOn { get; set; }
        public string MsgReceivedOn => MsgSentOn; // aynıysa
    }
}

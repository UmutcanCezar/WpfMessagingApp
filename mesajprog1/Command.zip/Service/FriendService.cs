﻿using mesajprog1.Dto;
using mesajprog1.Model;
using mesajprog1.View;
using mesajprog1.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;


namespace mesajprog1.Service
{
    class FriendService
    {
        public ObservableCollection<FriendDto> Friends { get; set; } = new();
        private readonly HttpClient _httpClient;
        public FriendService()
        {
            _httpClient = new HttpClient { BaseAddress = new Uri("http://localhost:5298/") };
        

        }
        public async Task<List<FriendDto>> LoadFriends(int userid)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<FriendDto>>($"api/Friend/{userid}");
            }
            catch (HttpRequestException httpEx)
            {
                // Loglama veya hata mesajı
                System.Diagnostics.Debug.WriteLine($"HTTP Error: {httpEx.Message}");
                return new List<FriendDto>(); // veya null dönebilirsin
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"General Error: {ex.Message}");
                return new List<FriendDto>();
            }
        }
        }
        

    }


﻿using mesajprog1.Dto;
using mesajprog1.Model;
using mesajprog1.View;
using mesajprog1.ViewModel;
using Microsoft.AspNetCore.SignalR.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;

namespace mesajprog1.Service
{
    public class MessageService
    {
        private HubConnection _connection;
        private readonly HttpClient _httpClient;
        public event Action<int, int, string> MessageReceived;

        public MessageService()
        {

            _httpClient = new HttpClient();
        }


        public async Task<List<MessageDto>> GetMessagesAsync(int user1Id, int user2Id)
        {
            var response = await _httpClient.GetAsync($"https://localhost:5001/api/Message/{user1Id}/{user2Id}");

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<MessageDto>>(json);
            }

            return new List<MessageDto>();
        }
        public async Task ConnectAsync(string userId)
        {
            _connection = new HubConnectionBuilder().WithUrl("https://localhost:5298/chatHub", options =>
            {
                options.Headers.Add("UserId", userId); // gerekiyorsa auth
            })
            .WithAutomaticReconnect()
            .Build();
            _connection.On<int, int, string>("ReceiveMessage", (senderId, receiverId, message) =>
            {
                MessageReceived?.Invoke(senderId, receiverId, message);
            });
        }
        public async Task SendMessage(int senderId, int receiverId, string message)
        {
            if (_connection.State == HubConnectionState.Connected)
            {
                await _connection.InvokeAsync("SendMessage", senderId, receiverId, message);

            }
        }
    }
}

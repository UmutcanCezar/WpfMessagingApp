﻿using mesajprog1.Model;
using mesajprog1.Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mesajprog1.ViewModel
{
    public class ChatConversationViewModel
    {
        public ObservableCollection<Message> Conversations { get; set; }
        public readonly MessageService _messageservice = new();
        private readonly MessageService _messageService = new MessageService();

        public ChatConversationViewModel()
        {
            _ = _messageservice.ConnectAsync("1");
            _messageservice.MessageReceived += OnMessageReceived;
            _ = LoadMessagesAsync(CurrentUser.Currentuser.Id, CurrentFriend.Currentfriend.FriendId);

        }
        public async Task LoadMessagesAsync(int user1Id, int user2Id = 0)
        {
            var messages = await _messageService.GetMessagesAsync(user1Id, user2Id);

            Conversations.Clear();

            foreach (var msg in messages)
            {
                Conversations.Add(new Message
                {
                    IsMessageReceived = msg.SenderID != user1Id,
                    SentMessage = msg.Content,
                    MsgSentOn = msg.SentAt.ToShortTimeString()
                });
            }
        }
        private void OnMessageReceived(int senderId,int ReceiverId,string message)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Conversations.Add(new Message
                {
                    IsMessageReceived = true,
                    SentMessage = message,
                    MsgSentOn = DateTime.Now.ToShortTimeString()
                });
            });
        }
    }
}

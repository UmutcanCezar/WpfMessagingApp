﻿using mesajprog1.Command;
using mesajprog1.Dto;
using mesajprog1.Model;
using mesajprog1.Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace mesajprog1.ViewModel
{
    public class FriendsViewModel : ViewModelBase
    {



        private readonly FriendService __friendservice;
        public ObservableCollection<FriendDto> Friends { get; set; } = new();
        public ICommand SelectFriendCommand => new RelayCommand<FriendDto>(SelectFriend);
        public FriendsViewModel()
        {
            __friendservice = new FriendService();
           _ =  InitializeAsync();
        }
        private void SelectFriend(FriendDto friend)
        {
            if(friend!= null) CurrentFriend.Currentfriend = friend;
        }

        private async Task InitializeAsync()
        {
            await LoadFriendsAsync();
        }

        private async Task LoadFriendsAsync()
        {
            if(CurrentUser.Currentuser == null)
            {
                return;

            }
            var friendlist = await __friendservice.LoadFriends(CurrentUser.Currentuser.Id);
            if (friendlist != null) {
                Friends.Clear();
                foreach (var firend in friendlist) {
                Friends.Add(firend);
                
                }
            
            }
        }

    }

}
